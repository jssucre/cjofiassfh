interface Props {
  top?: string; // 上//距
  bottom?: string; // 下//距
  list?: JSX.Element; // 列//表
  background?: string; // 背//景色
  noMoreVisible?: boolean; // 没//有更多是否显示
  noMoreText?: string; // 没//有更多的文案，默认 没有更多了～
  type?: string; // 类//型
  handlePull?: (handleComplete: () => void) => void; // 下拉事件
}

// /**
//  * 超级列表
//  * @string top ? 上距
//  * @string bottom ? 下距
//  * @Element list 列表
//  * @boolean noMoreVisible ? 没有更多是否显示
//  * @string noMoreText ? 没有更多的文案，默认 没有更多了～
//  * @function handlePull ? 下拉事件
//  */
export default class ListX extends React.PureComponent<Props, any> {
  constructor(props) {
    super(props);
    this.state = { ...this.initialInfo };
  }

  /**
   * 初始化信息
   */
  public initialInfo = {
    moveNum: 0,
    pullDistance: 0,
    pullVisible: false,
    loadingVisible: false,
  };

  /**
   * content的ref
   */
  private contentRef = React.createRef<HTMLDivElement>();

  // list的ref
  private listRef = React.createRef<HTMLDivElement>();

  /**
   * 节点
   */
  private listNode: any;

  /**
   * 列表高度
   */
  public maxMove = 0;

  /**
   * 开始的y值
   */
  public startY = 0;

  /**
   * 结束移动数
   */
  public endMoveNum = 0;

  /**
   * 开启拉取启动高度
   */
  public openPullHeight = 50;

  /**
   * 速度
   */
  public speedObj = {
    speed: 0,
    beforeDistanceY: 0,
  };

  /**
   * 锁定触摸
   */
  public localTouch = false;

  public componentDidMount() {
    helpers.forbidScoll(true);
    this.listNode = this.listRef.current;

    setTimeout(() => {
      this.handleCalculateMaxMove();
      if (this.maxMove > 0) {
        this.handleAddTouchListenter();
      }
    });
  }

  public componentWillUnmount() {
    helpers.forbidScoll(false);
    // 移除监听
    this.handleRemoveTouchListenter();
  }

  public componentDidUpdate(nextProps) {
    if (this.props.type !== nextProps.type) {
      this.setState({ ...this.initialInfo });
      this.endMoveNum = 0;
      setTimeout(() => {
        this.handleCalculateMaxMove();
      }, 200);
    }
  }

  /**
   * 计算最大移动
   */
  public handleCalculateMaxMove = () => {
    const contentHeight = _.get(this.contentRef.current, "clientHeight") || 0;
    const listHeight = this.listNode.clientHeight;
    this.maxMove = listHeight - contentHeight;
  };

  /**
   * 计算速度
   */
  public handleCalculateSpeed = (distanceY: number) => {
    this.speedObj.beforeDistanceY =
      this.speedObj.beforeDistanceY === 0
        ? distanceY
        : this.speedObj.beforeDistanceY;
    this.speedObj.speed = Math.floor(distanceY - this.speedObj.beforeDistanceY);
    this.speedObj.beforeDistanceY = distanceY;
  };

  /**
   * 惯性移动
   */
  public handleInertiaMove = (speed: number) => {
    const { moveNum } = this.state;
    const distanceY = moveNum + speed;
    if (this.speedObj.speed === 0 || speed === 0) {
      return;
    }

    if (distanceY < this.maxMove * -1) {
      this.endMoveNum = this.maxMove * -1;
      this.setState({
        moveNum: this.maxMove * -1,
      });
      return;
    }

    if (distanceY > 0) {
      this.endMoveNum = 0;
      this.setState({
        moveNum: 0,
      });
      return;
    }

    setTimeout(() => {
      this.endMoveNum = distanceY;
      this.setState({
        moveNum: distanceY,
      });
      this.handleInertiaMove(speed > 0 ? speed - 1 : speed + 1);
    }, 15);
  };

  /**
   * 触摸开始
   */
  public handleTouchstartHandler = (e) => {
    if (this.localTouch) {
      return;
    }
    this.startY = e.changedTouches[0].clientY;
    this.handleCalculateMaxMove();
    this.speedObj.speed = 0;
    this.speedObj.beforeDistanceY = 0;
  };

  /**
   * 移动中
   */
  public handleTouchmoveHandler = (e) => {
    if (this.localTouch || this.maxMove <= 0) {
      return;
    }
    const { noMoreVisible, handlePull } = this.props;

    // 获取y移动距离
    const distanceY =
      e.changedTouches[0].clientY - this.startY + this.endMoveNum;
    const translateDistanceY =
      distanceY > 0
        ? 0
        : distanceY < this.maxMove * -1
        ? this.maxMove * -1
        : distanceY;

    this.handleCalculateSpeed(distanceY);

    if (
      translateDistanceY === this.maxMove * -1 &&
      !noMoreVisible &&
      handlePull
    ) {
      this.setState({
        pullDistance: Math.floor(distanceY - translateDistanceY) / 2,
        loadingVisible:
          Math.floor(distanceY - translateDistanceY) / 2 <=
          -1 * (this.openPullHeight + 40),
        pullVisible: true,
      });
    } else {
      this.setState({
        moveNum: Math.floor(translateDistanceY),
      });
    }
  };

  /**
   * 移动结束
   */
  public handleTouchendHandeler = (e) => {
    if (this.localTouch) {
      return;
    }
    const { pullDistance } = this.state;
    this.endMoveNum = this.state.moveNum;
    if (pullDistance !== 0) {
      this.localTouch = true;
      this.handlePullBack(1);
    } else {
      this.handleInertiaMove(this.speedObj.speed);
    }
  };

  /**
   * 拉取回复
   */
  public handlePullBack = (speed: number) => {
    const { pullDistance, loadingVisible, moveNum } = this.state;
    const { handlePull, noMoreVisible } = this.props;
    if (pullDistance === 0 || noMoreVisible) {
      return;
    }

    if (loadingVisible && this.openPullHeight * -1 <= pullDistance) {
      this.setState({
        pullDistance: this.openPullHeight * -1,
      });
      if (handlePull) {
        handlePull(() => {
          this.setState({
            loadingVisible: false,
            pullVisible: false,
          });
          setTimeout(() => {
            const maxMove = this.maxMove;
            this.handleCalculateMaxMove();

            if (this.maxMove === maxMove) {
              this.handlePullBack(10);
            } else {
              this.localTouch = false;
              this.endMoveNum = moveNum + pullDistance;
              this.setState({
                pullDistance: 0,
                pullVisible: true,
                moveNum: this.endMoveNum,
              });
            }
          }, 200);
        });
      }
      return;
    }

    const distance = Math.floor(pullDistance) + speed;
    if (distance < 0) {
      this.setState(
        {
          pullDistance: distance,
        },
        () => {
          setTimeout(() => {
            this.handlePullBack(speed > 15 ? 15 : speed + 1);
          }, 10);
        }
      );
    } else {
      this.localTouch = false;
      this.setState({
        pullDistance: 0,
        pullVisible: true,
      });
    }
  };

  /**
   * 添加触摸监听
   */
  public handleAddTouchListenter = () => {
    this.listNode.addEventListener("touchstart", this.handleTouchstartHandler); // 滑动开始绑定的函数
    this.listNode.addEventListener("touchmove", this.handleTouchmoveHandler); // 持续滑动绑定的函数
    this.listNode.addEventListener("touchend", this.handleTouchendHandeler); // 滑动结束绑定的函数
    this.listNode.addEventListener("touchcancel", this.handleTouchendHandeler); // 滑动结束绑定的函数
  };

  /**
   * 移除触摸监听
   */
  public handleRemoveTouchListenter = () => {
    this.listNode.removeEventListener(
      "touchstart",
      this.handleTouchstartHandler
    );
    this.listNode.removeEventListener("touchmove", this.handleTouchmoveHandler);
    this.listNode.removeEventListener("touchend", this.handleTouchendHandeler);
    this.listNode.removeEventListener(
      "touchcancel",
      this.handleTouchendHandeler
    );
  };

  public render() {
    const {
      top,
      bottom,
      list,
      background,
      noMoreVisible,
      noMoreText,
      handlePull,
    } = this.props;

    const { pullDistance, moveNum, loadingVisible, pullVisible } = this.state;
    const pullDistance2 = moveNum + pullDistance;

    return (
      <>
        <div
          className={listXStyle.listMore}
          style={{
            top,
            bottom,
          }}
          ref={this.contentRef}
        >
          <div
            ref={this.listRef}
            style={{
              background,
              transform: `translateY(${pullDistance2}px)`,
            }}
            id={"listX"}
          >
            {list}
            {noMoreVisible && noMoreText !== "" ? (
              <div className={listXStyle.noMore}>
                {noMoreText ? noMoreText : "没有更多了～"}
              </div>
            ) : null}
          </div>
        </div>
        {handlePull && pullVisible && !noMoreVisible ? (
          <div
            className={listXStyle.pull}
            style={{
              bottom,
              height: Math.abs(pullDistance),
              lineHeight: `${Math.abs(pullDistance)}px`,
            }}
          >
            {loadingVisible ? "拉取更多" : "拉取更多"}
          </div>
        ) : null}
      </>
    );
  }
}
